import databus from '../databus'
const audios = databus.resources.audios

export default {
    playSwooshing() {
        audios.swooshing.currentTime = 0
        audios.swooshing.play();
    },

    playWing() {
        audios.wing.currentTime = 0
        audios.wing.play()
    },

    playPoint() {
        audios.point.currentTime = 0
        audios.point.play()
    },

    playDie() {
        audios.hit.currentTime = 0
        audios.hit.play();

        audios.die.currentTime = 0
        audios.die.play()
    }
}