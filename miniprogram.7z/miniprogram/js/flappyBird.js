
//游戏主对象
//作用:   1. 加载游戏中所有的资源,音乐和图片
//          2.等到资源加载完成,开户游戏主循环,开始游戏
//3.控制游戏时间


import './libs/weapp-adapter';
import config from './config';
import databus from './databus';
import sceneManager from './scene/index';

const context = canvas.getContext('2d')
// console.log(1);
export default class FlappyBird {

    constructor() {
        // console.log(3);
        this.render = this.render.bind(this);
        //调用start方法开始游戏
        this.start();
    }

    //开始游戏
    start() {
        // console.log(4);
        //加载游戏资源
        this.loadResources()
            .then(() => {
                // console.log(6);
                //在此处开始游戏
                //提供游戏时间
                //时间间隔 = 当前帧的时间 - 上一帧的时间
                this.delta = 0;
                this.curFrameTime = new Date() - 0;
                this.lastFrameTime = new Date() - 0;

                window.requestAnimationFrame(this.render);
                canvas.addEventListener('touchstart',function (e){
                    sceneManager.click(e);
                })
            });
    }

    //渲染当前场景
    render() {
        // console.log(7);
        this.curFrameTime = new Date() - 0;
        this.delta = (this.curFrameTime - this.lastFrameTime) / 1000;
        this.lastFrameTime = this.curFrameTime;

        // console.log(this.delta);
        //调用当前场景的渲染方法,场景再渲染场景中的角色
        // console.log("渲染当前场景");
        //渲染流程
        //1.主循环调用场景管理器中的render方法
        //2.场景管理器调用当前场景的render方法
        //3.当前场景调用场景中每个角色的render方法
        //4.每个角色自己通过render方法渲染自己到页面中
        sceneManager.render(context, this.delta);
        window.requestAnimationFrame(this.render);
    }



    //加载游戏资源
    //如何判断所有游戏资源全部加载完成?
    //思路:  每加载完成一个游戏资源,就记录这个数量加1,当记录加载加载完成的数量与游戏资源的总数量相同时,就说明所有游戏资源加载完成了
    loadResources() {
        // console.log("加载资源5");
        //加载所有的图片和音乐
        //当所有的资源加载完毕后,才能开始游戏

        //为什么要将所有的资源放到一个数组中?
        //因为我们要等到所有的资源加载完成,而放到一个数组中会更方便
        const resourceList = [
            ...config.resources.IMG_NAME_LIST,
            ...config.resources.MUSIC_NAME_LIST
        ];

        let resource = null;
        //当前加载完成的资源总量
        let loadedCount = 0;

        return new Promise((resolve, reject) => {
            resourceList.forEach((resourceName) => {
                if (resourceName.endsWith('.png')) {
                    //加载图片资源
                    resource = new Image();
                    //资源路径必须是绝对路径
                    resource.src = `images/${resourceName}`;
                    databus.resources.images[resourceName.slice(0, -4)] = resource;
                } else if (resourceName.endsWith('.mp3')) {
                    //加载声音资源
                    resource = new Audio();
                    //资源路径必须是绝对路径
                    resource.src = `audio/${resourceName}`;
                    databus.resources.audios[resourceName.slice(0, -4)] = resource;
                }

                resource.addEventListener('load', () => {
                    loadedCount++;
                    if (loadedCount === resourceList.length) {
                        //所有资源已加载完成
                        console.log('所有资源已加载完成,loadedCount:' + loadedCount);
                        resolve();
                    }
                });

                //资源加载失败
                //哪个资源加载失败就重新加载哪个资源,或重新调用加载资源的方法
                resource.addEventListener('error', () => {
                    reject();
                })
            });
        });
    }



}