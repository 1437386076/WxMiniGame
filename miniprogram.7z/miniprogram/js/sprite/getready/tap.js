//replay 角色,只负责创建角色并导出即可
import Sprite from '../../base/sprite';
import config from '../../config'

export default new Sprite({
    img: 'tap',
    ...config.gameInfo.tap
});