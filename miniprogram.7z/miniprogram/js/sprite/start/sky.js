import Sprite from '../../base/sprite'
import config from '../../config'

export default new Sprite({
    img: 'sky',
    ...config.gameInfo.sky
})