//replay 角色,只负责创建角色并导出即可
import Sprite from '../../base/sprite';
import config from '../../config'
import sceneManager from '../../scene/index'
import music from '../../music/index'

export default new Sprite({
    img: 'replay',
    ...config.gameInfo.replay,

    click(){
        music.playSwooshing()
        sceneManager.changScene("getready");
    }
});