import Sprite from '../../base/sprite'
import config from '../../config'
import databus from '../../databus';

export default new Sprite({
    img: "birds",
    ...config.gameInfo.bird,
    a: 9.8,
    speed: 0,
    tag: 0,
    count: 0,
    render(context, delta) {

        //小鸟下落,采用匀加速直线运动
        //速度公式
        // S = V * T  +  1/2 * a * t * t   顺时的速度
        // V = V0 + a * t   速度
        this.speed += this.a * delta;//每帧的速度
        this.y += (this.speed * delta + 1 / 2 * this.a * delta * delta) * 15;//位移
        // console.log(this.apeed);
        // console.log(this.y);

        if (this.y > 220) {
            this.speed = -5.5;
        }

        let img = databus.resources.images[this.img];
        let x = (databus.screenWidth - this.width) / 2

        if (this.tag === 0) {
            context.drawImage(img, 0, 0, this.width, this.height, x, this.y, this.width, this.height);
            if (this.count++ >= 20) {
                this.count = 0;
                this.tag = 1;
            }

        } else if (this.tag === 1) {
            context.drawImage(img, this.width, 0, this.width, this.height, x, this.y, this.width, this.height);
            if (this.count++ >= 20) {
                this.count = 0;
                this.tag = 2;
            }
        }
        else {
            context.drawImage(img, this.width * 2, 0, this.width, this.height, x, this.y, this.width, this.height);
            if (this.count++ >= 20) {
                this.count = 0;
                this.tag = 0;
            }
        }



        // context.drawImage(img, 0, 0, this.width, this.height, x, this.y, this.width, this.height);
    }
})