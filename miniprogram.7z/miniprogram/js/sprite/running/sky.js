import Sprite from '../../base/sprite'
import config from '../../config'

const skyList=[];

for(let i =0; i < 2; i++){
    const skySprite = new Sprite({
        img: 'sky',
        ...config.gameInfo.sky,
        x: i * config.gameInfo.sky.width,
        update()
        {
            this.x += this.speed;
            if(this.x <= -this.width){
                this.x += this.width *2;
            }
        },

        init(){
            this.x = i * config.gameInfo.sky.width
        }
    });

    skyList.push(skySprite);
}

export default skyList