import Sprite from '../../base/sprite'
import config from '../../config'
import databus from '../../databus';
//小鸟可飞行 的最大高度
const Max_Height = databus.screenHeight - config.gameInfo.land.height
export default new Sprite({
    img: "birds",
    ...config.gameInfo.bird,
    a: 9.8,
    speed: 0,
    //最大角度
    Max_Angle: 90,
    //最大速度
    Max_Speed: 12,

    init(){
        this.y = config.gameInfo.bird.y;
        this.speed = 0;
    },

    render(context, delta) {

        //小鸟下落,采用匀加速直线运动
        //速度公式
        // S = V * T  +  1/2 * a * t * t   顺时的速度
        // V = V0 + a * t   速度
        this.speed += this.a * delta;//每帧的速度
        this.y += (this.speed * delta + 1 / 2 * this.a * delta * delta) * 30;//位移
        if (this.y >= Max_Height) {
            this.y = Max_Height
        }
        //第一先保存
        context.save();
        //小鸟的旋转,需要先平移再旋转
        //平移原点
        context.translate(this.x, this.y)
        //公式:  当前速度 / 最大速度 = 当前角度 / 最大角度
        //当前角度 = 当前速度 / 最大速度 * 最大角色
        let curAngle = this.speed / this.Max_Speed * this.Max_Angle
        if (curAngle >= this.Max_Angle) {
            curAngle = this.Max_Angle
        }
        //旋转(弧度)
        context.rotate(curAngle / 180 * Math.PI)

        let img = databus.resources.images[this.img];

        //因为场景的原点平移到了小鸟的中心,所以需要设置渲染小鸟的坐标为 负的1/2宽和1/2高,就正好小鸟的中心就在场景的原点上
        context.drawImage(img, 0, 0, this.width, this.height, -this.width / 2, -this.height / 2, this.width, this.height);

        //画完之后就重置,避免影响其它角色的渲染
        context.restore();
    }
})