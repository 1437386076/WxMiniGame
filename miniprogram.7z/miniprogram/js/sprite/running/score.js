import Sprite from '../../base/sprite'
import databus from '../../databus'
import config from '../../config'

const scoreConfig = config.gameInfo.curScore

export default new Sprite({
    render(context) {
        let scoreText = databus.score
        context.font = scoreConfig.font;
        context.fillStyle = scoreConfig.fillStyle;
        let scoreWidth = context.measureText(scoreText).width;
        context.fillText(scoreText, (databus.screenWidth - scoreWidth) / 2, scoreConfig.y);
    }
})