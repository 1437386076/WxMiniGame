import Sprite from '../../base/sprite'
import config from '../../config'
import databus from '../../databus'

const pipeList = [];
const pipeConfig = config.gameInfo.pipe
for (let i = 0; i < 3; i++) {
    const pipeSprite = new Sprite({
        img: 'pipe_top',
        img_bottom: 'pipe_bottom',
        ...pipeConfig,
        scoreMake: false,
        x: i * (pipeConfig.width + pipeConfig.horizontalGap) + databus.screenWidth,
        init() {
            this.x = i * (pipeConfig.width + pipeConfig.horizontalGap) + databus.screenWidth
            this.setPipeY();
            this.scoreMake = false;
        },

        //每渲染一次都当前保存管道的坐标
        setPosition() {
            const position = {
                startX: this.x,
                startY: this.y,
                endX: this.x + this.width,
                endY: this.y + this.height
            }

            this.position = {
                top: position,
                bottom: {
                    ...position,
                    startY: this.bottomY,
                    endY: this.bottomY + this.height
                }
            }
        },

        setPipeY() {
            let pipeTopHeight = Math.random() * 200 + 150;
            this.y = pipeTopHeight - this.height;
            this.bottomY = pipeTopHeight + this.verticalGap;
        },

        update() {
            this.x += this.speed;
            if (this.x <= - (this.width + this.horizontalGap)) {
                this.x += (this.width + this.horizontalGap) * 3
                this.setPipeY();
                this.scoreMake = false;
            }

            this.setPosition()
        },

        //渲染自己的方法
        render(context) {
            context.drawImage(databus.resources.images[this.img], this.x, this.y, this.width, this.height);
            context.drawImage(databus.resources.images[this.img_bottom], this.x, this.bottomY, this.width, this.height);
        }

    });

    pipeList.push(pipeSprite);
}

export default pipeList