import Sprite from '../../base/sprite'
import databus from '../../databus'
import config from '../../config'

const scoreConfig = config.gameInfo.score

export default new Sprite({
    render(context) {
        let scoreText = `Score : ${databus.score}`
        let bestScoreText = `Best : ${databus.bestScore}`
        context.font = scoreConfig.font;
        context.fillStyle = scoreConfig.fillStyle;
        let scoreWidth = context.measureText(scoreText).width;
        let bestScoreWidth = context.measureText(bestScoreText).width;
        context.fillText(scoreText, (databus.screenWidth - scoreWidth) / 2, scoreConfig.scoreY);
        context.fillText(bestScoreText, (databus.screenWidth - bestScoreWidth + 24) / 2, scoreConfig.bestY)
    }
})