// 这是精灵基类
// 作用: 用来创建所有的游戏精灵(角色)
// 这个类中应该提供所有游戏精灵的一些公共的属性或方法
// 精灵特有的属性或方法应该放在精灵对象自身
import databus from '../databus'

export default class Sprite {
     
     constructor(config) {
          for (let k in config) {
               this[k] = config[k];
          }

          this.init();
     }

     init(){

      }

      click(){
           
      }
      
     update(){

     }

     //渲染自己的方法
     render(context) {
          // console.log("渲染精灵的方法");
          //canvas中用来绘制图片的方法
          //drawImage()方法的第一个参数是一个图片对象
          context.drawImage(databus.resources.images[this.img], this.x, this.y, this.width, this.height);
          // context.drawImage(this.img,this.x,this.y,this.width,this.height);
     }
}