import databus from '../databus'

export default class Scene {
    constructor(config) {
        //传入场景中所有的精灵(角色)
        for (let k in config) {
            this[k] = config[k]
        }
    }

    update() {

    }

    init(){
       
    }

    initRoles(rolesPre){

    }

    click(e) {
        //获取当前点击的x和y坐标
        let clientX = e.touches[0].clientX;
        let clientY = e.touches[0].clientY;

        //循环遍历,并调用当前场景中所有角色, 调用满足条件的角色的click方法
        this.roles.forEach(role => {
            if (clientX >= role.x && clientX <= (role.x + role.width) && clientY >= role.y && clientY <= (role.y + role.height)) {
                role.click();
            }
        })
    }

    //渲染当前场景
    //遍历当前场景中所有的角色对象,分别调用每个角色的渲染自己的方法
    render(context, delta) {
        this.roles.forEach((role) => {
            role.render(context, delta);
            //当前游戏结束后就不再更新
            if (!databus.isGameOver) {
                role.update();
            }
        });

        this.update();
    }

}