//导入场景类型
import Scene from "../base/scene";
//导入getready场景中的精灵(角色)
import getready from '../sprite/getready/getready';
import tap from '../sprite/getready/tap'
import sky from '../sprite/getready/sky'
import landList from '../sprite/getready/land'
import bird from '../sprite/getready/bird'
import sceneManager from '../scene/index'
import music from '../music/index'

//创建并导出getready场景对象
export default new Scene({
    //当前场景中的角色列表
    roles: [
        //注意: 角色添加的顺序问题,先添加进来的角色会被渲染在最下面
        sky,
        getready,
        tap,
        ...landList,
        bird
    ],

    click(e){
        music.playWing()
        sceneManager.changScene("running")
    }
});