//导入场景类型
import Scene from "../base/scene";
//导入场景中的精灵(角色)
import pipeList from '../sprite/running/pipe'
import skyList from '../sprite/running/sky'
import landList from '../sprite/running/land'
import bird from '../sprite/running/bird'
import score from '../sprite/running/score'
import databus from '../databus'
import sceneManager from '../scene/index'
import music from '../music/index'

//创建并导出场景对象
export default new Scene({
    //当前场景中的角色列表
    roles: [
        //注意: 角色添加的顺序问题,先添加进来的角色会被渲染在最下面
        ...skyList,
        ...pipeList,
        ...landList,
        score,
        bird
    ],
    bird,
    land0: landList[0],
    //是否碰撞
    isCollision: false,
    //是否触地
    isLand: false,

    init() {
        //是否碰撞
        this.isCollision = false
        //是否触地
        this.isLand = false

        this.roles.forEach(role => {
            role.init()
        })
    },

    //判断是否发生碰撞
    //检测传进来的小鸟坐标 与 管道坐标有没有重合,重合了就说明碰撞了
    isCollisionWith(bird, pipePosition) {
        if (bird.x >= pipePosition.startX && bird.x <= pipePosition.endX && bird.y >= pipePosition.startY && bird.y <= pipePosition.endY) {
            return true
        }

        return false
    },

    //判断小鸟是否触地
    isLanded() {
        return this.bird.y >= this.land0.y
    },

    //碰撞检测
    collisionDetecton() {

        //some()方法返回bool
        return pipeList.some(pipe => {
            return this.isCollisionWith(this.bird, pipe.position.top) || this.isCollisionWith(this.bird, pipe.position.bottom)
        })
    },

    //积分
    setScore() {
        pipeList.forEach(pipe => {
            if (!pipe.scoreMake && (bird.x > (pipe.x + pipe.width))) {
                databus.score += 1
                music.playPoint()
                pipe.scoreMake = true;
            }
        })
    },

    //如果小鸟是和管道碰撞的,那么小鸟落地后再出现GameOver
    //如果小鸟和陆地碰撞,那就直接出现GameOver
    update() {


        if (!this.isCollision) {
            this.isCollision = this.collisionDetecton();
            if (this.isCollision) {
                console.log("碰碰碰");
                databus.isGameOver = true;
                music.playDie()
            }

            this.setScore();
        }

        if (!this.isLand) {
            this.isLand = this.isLanded();
            

            if (this.isLand) {
                if (!databus.isGameOver) {
                    music.playDie()
                }

                databus.bestScore = databus.score > databus.bestScore ? databus.score : databus.bestScore
                databus.isGameOver = true;
                console.log("切换场景")
                music.playSwooshing()
                sceneManager.changScene("gameover")
            }
        }
    },

    click(e) {
        if (!databus.isGameOver) {
            music.playWing()
            this.bird.speed = -6;
        }
    }
});