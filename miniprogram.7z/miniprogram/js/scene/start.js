//导入场景类型
import Scene from "../base/scene";
//导入start场景中的精灵(角色)
import flappyBirdTitle from '../sprite/start/flappyBirdTitle';
import replay from '../sprite/start/replay'
import sky from '../sprite/start/sky'
import landList from '../sprite/start/land'
import bird from '../sprite/start/bird'

//创建并导出start场景对象
export default new Scene({
    //当前场景中的角色列表
    roles: [
        //注意: 角色添加的顺序问题,先添加进来的角色会被渲染在最下面
        sky,
        flappyBirdTitle,
        replay,
        ...landList,
        bird
    ]
});
