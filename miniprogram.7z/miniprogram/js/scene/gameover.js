import Scene from '../base/scene'
import replay from '../sprite/gameover/replay'
import gameoverTitle from '../sprite/gameover/gameoverTitle'
import score from '../sprite/gameover/score'

export default new Scene({
    roles: [
        gameoverTitle,
        replay,
        score
    ],

    //复用上一个场景中的角色
    initRoles(rolesPre) {
        this.roles = [...rolesPre, ...this.roles];
    }
})