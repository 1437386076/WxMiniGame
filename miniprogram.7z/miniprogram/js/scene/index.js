/**
 * 这是游戏场景管理器
 * 作用:
 * 1.管理游戏中所有的场景
 * 2.渲染场景
 * 3.切换场景
 * 4.处理当前场景的事件
 *  */
import start from './start';
import getready from './getready'
import running from './running'
import gameover from './gameover'

export default {
    //场景的集合
    sceneList: {
        start,
        getready,
        running,
        gameover
    },
    //当前场景的名称,默认为"start"
    currnetSceneName: 'start',

    //渲染场景
    render(context, delta) {
        //  console.log("场景管理器开始渲染!");
        //根据当前场景的名称,获取到当前场景,并渲染
        this.sceneList[this.currnetSceneName].render(context, delta);
    },


    click(e) {
        this.sceneList[this.currnetSceneName].click(e);
    },

    //切换场景
    changScene(sceneName) {
        //在些复用上一个场景中的角色传递给当前场景
        //1.获取上一个场景中的角色
        var rolesPre = this.sceneList[this.currnetSceneName].roles;
        //2.调用当前场景的初始化角色的方法
        this.sceneList[sceneName].initRoles(rolesPre);
        this.sceneList[sceneName].init()
        this.currnetSceneName = sceneName
    }
}