//游戏的公共数据
//提供游戏状态 (gameover,score)
export default {
    //游戏资源
    resources: {
        images: {},
        audios: {}
    },

    //屏幕的宽度和调试
    screenWidth: window.innerWidth,
    screenHeight: window.innerHeight,
    isGameOver: false,
    //当前积分
    score: 0,
    bestScore: 0
}