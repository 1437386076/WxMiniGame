//这是游戏的入口
//在入口中实例化游戏主对象 (flappyBird.js)
//游戏主对象中,开户主循环,负责渲染当前场景

import './js/libs/weapp-adapter';

//导入游戏主对象,开始游戏
import flappyBird from './js/flappyBird';
new flappyBird();